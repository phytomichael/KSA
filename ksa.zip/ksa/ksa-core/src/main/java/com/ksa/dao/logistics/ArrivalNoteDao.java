package com.ksa.dao.logistics;

import com.ksa.model.logistics.ArrivalNote;


public interface ArrivalNoteDao extends AbstractLogisticsModelDao<ArrivalNote> {

}
