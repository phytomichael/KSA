package com.ksa.dao.logistics;

import com.ksa.model.logistics.Manifest;


public interface ManifestDao  extends AbstractLogisticsModelDao<Manifest> {

}
