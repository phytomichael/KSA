package com.ksa.dao.logistics;

import com.ksa.model.logistics.WarehouseBooking;


public interface WarehouseBookingDao  extends AbstractLogisticsModelDao<WarehouseBooking> {

}
