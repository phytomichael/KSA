package com.ksa.dao.logistics;

import com.ksa.model.logistics.BillOfLading;


public interface BillOfLadingDao extends AbstractLogisticsModelDao<BillOfLading> {

}
