package com.ksa.dao.logistics;

import com.ksa.model.logistics.WarehouseNoting;


public interface WarehouseNotingDao  extends AbstractLogisticsModelDao<WarehouseNoting> {

}
